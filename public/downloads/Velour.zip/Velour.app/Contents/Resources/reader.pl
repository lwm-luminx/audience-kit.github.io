#!/usr/bin/perl
# Loads Velour's now-playing reader into perl and runs it: macOS answers now-playing reads only for Apple's own
# programs, and /usr/bin/perl is one. Usage: /usr/bin/perl reader.pl /path/to/libVelvetNowPlaying.dylib
use strict;
use warnings;
use DynaLoader;

my $path = shift @ARGV or die "usage: reader.pl LIBRARY\n";
my $library = DynaLoader::dl_load_file($path, 0) or die "can't load $path: " . DynaLoader::dl_error() . "\n";
my $symbol = DynaLoader::dl_find_symbol($library, "velvet_helper_stream") or die "velvet_helper_stream is missing\n";
DynaLoader::dl_install_xsub("main::velvet_helper_stream", $symbol);
$| = 1;
main::velvet_helper_stream();
