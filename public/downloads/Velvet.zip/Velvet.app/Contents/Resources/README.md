# Velvet Display (macOS)

A Mac at the venue shows Velvet's marquee on every screen you pick, any mix of displays plugged into it, Chromecasts
and AirPlay TVs on its network: tonight's lineup with
whoever is on now, the Hot Mess join code, the Hot Mess slogan slides the venue has on, and the room's live chat. It is
the same board Velvet on an iPhone or iPad puts on a TV (`VenueMarqueeBoard` in StaffKit's `VenueMarqueeUI` library,
`swift/Sources/VenueMarqueeUI`), so a change to the marquee shows up on both. The library builds for iOS, macOS and
tvOS, ready for an Apple TV app.

Open `apps/velvet/VelvetDisplay.xcodeproj` and run the **Velvet Display Next** scheme (Debug and Release talk to the next
preview, `https://api.next.audiencekit.com`) or **Velvet Display Production** (production). Signing team `DWVXMLB45Y`,
macOS 14 or later. It shares Velvet's bundle ID, `com.audiencekit.Velvet` (one bundle ID per app), as Velvet's macOS
platform on App Store Connect app 6820764256. Its device sign-in is one keychain item, service `com.audiencekit.Velvet`
(the bundle ID), for every build: App Store and Developer ID, Next and Production. It opens for the app's designated
requirement (team and bundle ID), which both signings meet, so moving between the download and the App Store app keeps
the sign-in. A narrower item, if one is ever needed, is `com.audiencekit.Velvet.<purpose>`. Builds before this read
`com.audiencekit.VelvetDisplay.{next,production}.audiencekit`; the first launch moves that sign-in over and deletes it.

## Setting it up at a venue

1. In Velvet on an iPhone or iPad, open the venue's Settings › Devices & codes and make a code with **Events & series**
   (the lineup). Add **Chat & moderation** to put the room's chat beside it.
2. On the Mac, enter the code. The Mac signs in as that venue device only, never as a person; revoking the device in
   Velvet takes the screen back to sign-in.
3. Pick the screens and press **Show** (⌘↩). ⌘. stops them all; on the Mac's own display, Escape does too.
   Showing never moves the Mac's sound: if macOS switches the output to a TV's or display's speakers (HDMI,
   DisplayPort or AirPlay) in the 30 seconds after Show or a display change, Velvet puts it back on the speakers that
   were playing (`AudioOutputGuard.swift`). Picking a TV's speakers yourself later is left alone.
   - **Displays**: any number of displays plugged into the Mac (the first one that isn't the Mac's main display is
     picked for you).
   - **Chromecasts**: Chromecasts and Google TVs found on the network (Bonjour `_googlecast._tcp`). The Mac speaks the
     Cast protocol itself (`MacCast.swift`): it launches Velvet's Cast receiver (`B2AF7F85`) and sends the board as
     text on `urn:x-cast:com.audiencekit.velvet`, the same messages the iPhone sends, and reconnects after a drop.
   - **AirPlay TVs as displays (preferred)**: in Control Center › Screen Mirroring, pick the Apple TV or AirPlay TV
     and choose **Use As Separate Display**. macOS then treats it as a display, so it appears under **Displays** and
     shows the board live, and the connection stays up while the Mac runs. An app can't start this itself (no public
     API), so it's set up once by hand; **Set Up an AirPlay TV as a Display…** opens Displays settings.
   - **AirPlay TVs as video (fallback)**: **Add AirPlay TV as Video** once per TV. Apps can't make an AirPlay TV a display, so the Mac draws the
     board offscreen twice a second, encodes it as live HLS (`MarqueeEncoder`/`MarqueeServer` in `VenueMarqueeUI`,
     shared with the iPhone's AirPlay stream) and plays it in one muted player per TV. After Show, pick each TV with
     its AirPlay button. macOS gives apps no way to pick an AirPlay route themselves, so after a restart the TVs have
     to be picked again.
4. Turn on **Open Velvet Display when this Mac starts**, so the displays and Chromecasts come back on their own after a
   restart.
5. Optionally turn on **Show what Spotify is playing**: with the Spotify app playing on the same Mac, the board shows
   the song, artist and cover along the bottom of the lineup. No Spotify sign-in: Spotify announces each track change
   to the Mac (`com.spotify.client.PlaybackStateChanged`), and the cover comes from asking Spotify over Apple Events,
   which macOS allows once (the `temporary-exception.apple-events` entitlement for `com.spotify.client`).

While it's showing, the display doesn't sleep and the pointer stays hidden over it. Unplugging the TV takes the board
down; plugging it back in (or waking the Mac) puts it back up. The venue is re-read every five minutes; the lineup every
minute and the chat live, as on the iPad.

## A different screen on each display

Each display picked in setup has its own **Shows** menu: Lineup and chat (the whole board, the default), Lineup only,
Chat wall, Event posters, or Sing-along lyrics. It's kept by the display's name. Chromecasts and the AirPlay video
stream always show the whole board; an AirPlay TV used as a separate display is a display like any other.

**Sing-along lyrics** show the line being sung, big, with the one before and the next two, and nothing else. They
follow Spotify on this Mac ("Show what Spotify is playing" must be on): Spotify's position comes with each play, pause
and track change, and is read again every 3 seconds. The words come only from where the venue may show them:
- its own LRC files in `~/Library/Application Support/Velvet Display/Lyrics` ("Artist - Title.lrc", the title alone,
  or the Spotify track ID), as a karaoke or sing-along licence supplies them;
- a timing another venue shared (`Venue.music.lyricTimings`, times and digests of the lines only), put to the words
  Musixmatch's `matcher.lyrics.get` gives the venue's key (the Basic plan has it);
- Musixmatch's synced lyrics (`matcher.subtitle.get`) with the venue's Musixmatch API key, entered in setup.

Every minute, each LRC named for its Spotify track ID ("<id>.lrc") that changed is shared with every venue
(`reportLyricTiming`, API #765) when the device code has the music permission: only line times and digests, never the
words. `[ti:]`, `[ar:]`, `[length:]` and `[matched:N]` (lines timed from the audio) tags go with it.

## Checking a build

```sh
xcodebuild -project apps/velvet/VelvetDisplay.xcodeproj -scheme "Velvet Display Next" -configuration Debug \
  -destination 'platform=macOS' CODE_SIGNING_ALLOWED=NO build
```

## App Store screenshots

`VelvetDisplayUITests` signs in to the demo venue (The Review Room) with its device code, which is the demo
audience's App Review code, and keeps three 2880×1800 Mac App Store screenshots: the device code screen, the setup
window signed in (each on Velvet's dark backdrop with a caption) and the marquee full screen. Run it on a Mac against
an API that has the demo audience (`rake ui_tests:setup` locally, or `rake app_review:venue`):

```sh
AK_REVIEW_CODE=XXXX-XXXX-XXXX-XXXX AK_API_URL=http://127.0.0.1:3000 \
  scripts/velvet-display-screenshots.sh ~/Desktop/velvet-display-shots
```

The test launches the app with `AK_UI_TEST_SIGNED_OUT=1`, so it signs in through a keychain item of its own and
never signs the Mac's real screen out, and it shows the board on the main display for a few seconds without changing
the display the Mac normally uses.

## The download (Developer ID, with Sparkle updates)

audiencekit.com/apps/velvet/ offers a Developer ID build, `https://audiencekit.com/downloads/VelvetDisplay.zip`, which
updates itself with [Sparkle](https://sparkle-project.org). Its feed is the API's appcast,
`https://api.audiencekit.com/v1/app_release/appcast?app=com.audiencekit.Velvet`, made live from Velvet's
`developer_id` release and signed by the API with the Sparkle EdDSA key in its credentials (`sparkle.ed25519_private_key`).
The same key sits in the login keychain of the Mac that builds the download (account `velvet-display`), which reads
only its public half for `SUPublicEDKey`:

```sh
AK_RELEASE_TOKEN=… scripts/velvet-display-direct.sh ~/Desktop/velvet-display-direct
```

It archives, exports for Developer ID, adds Sparkle.framework and the feed keys, signs with
`VelvetDisplay-Direct.entitlements` (the app's entitlements plus the mach-lookup exceptions sandboxed Sparkle needs),
notarizes, staples and zips, then reports the release (build, version, download URL, sha256) to the API. Put the zip
in audience-kit.github.io `public/downloads/` with a PR to main. The appcast offers the build only once the zip on the
site matches the reported sha256. The build number is the commit count, so each build is newer than the last.

The App Store build has no Sparkle in it: nothing in the Xcode project links it. `Updates.swift` loads Sparkle at run
time only when the bundle has the framework and `SUFeedURL`, and only then shows **Check for Updates…** in the app menu.

## Xcode Cloud

The Velvet product's **Velvet Display Next** workflow builds `apps/velvet/VelvetDisplay.xcodeproj` from `next` with the
"Velvet Display Next" scheme and archives it for macOS TestFlight (internal testers). `apps/velvet/ci_scripts/ci_post_clone.sh`
checks out the AudienceKit SDK submodule, as `apps/ci_scripts` does for Staff.xcodeproj.

## Tonight's music: event playlists and sing-along nights

An event or series with a playlist (`Event.playlist`, a Spotify link set in Velvet) plays in Spotify on this Mac while the
event runs (`NightMusic`), shuffled unless the playlist says otherwise. When the event is a sing-along night (karaoke
with the sing_along provider, `karaoke.singAlong`, or the sing_along facet's tag), every chosen screen turns to the
sing-along lyrics, and goes back to what it showed when the event ends. The setup window's "Tonight's music" section
lists tonight's nights with Play Now, takes a pasted Spotify link, and ends a night by hand.

"Time a song's lyrics" (`LyricTiming`, in the sing-along section) makes an LRC file from pasted lyrics and an audio file
of the song the venue owns: macOS speech recognition hears the song on this Mac, `LyricAligner` (StaffKitServices)
matches the heard words to the lines, and the file goes into the Lyrics folder. It's a first draft to check.

Each display's "Shows" is All by default: the lineup and chat, with event posters, photographers' photos, slogans and
the safety screen taking turns between looks at it. Picking one thing (lineup only, chat wall, event posters, photos,
sing-along lyrics) is the override for that screen.
