# Velvet Display (macOS)

A Mac at the venue shows Velvet's marquee on every screen you pick, any mix of displays plugged into it, Chromecasts
and AirPlay TVs on its network: tonight's lineup with
whoever is on now, the Hot Mess join code, the Hot Mess slogan slides the venue has on, and the room's live chat. It is
the same board Velvet on an iPhone or iPad puts on a TV (`VenueMarqueeBoard` in StaffKit's `VenueMarqueeUI` library,
`swift/Sources/VenueMarqueeUI`), so a change to the marquee shows up on both. The library builds for iOS, macOS and
tvOS; Velvet on Apple TV (`apps/velvet/VelvetTV`) shows it too.

Once signed in, the window is the venue's desk for the night, with a sidebar down the left that has a page for each
concern (`Workspace.swift`, laid out like Velvet's iPad sidebar since 2026-11-24: the audience and venue at its head,
then Tonight, Events, Chat and Back of House, then a This Mac group with Screens and Music; ⌘1 to ⌘6, and Show and
Stop in the toolbar from every page). The pages use the iPad's look: StaffKitUI cards (`akCard`) on `akSurface`, the
serif display face for titles, `Badge`s and `StatTile`s.

- **Tonight** (`TonightTab.swift`, the home page): the iPad's Tonight and manager's desk. Tonight's date, a card per
  event tonight (opens it on Events), who's on now and later (Next Act and Back with Events & series), the screens
  (Show or Stop), what's playing and the night's numbers, with the room's chat live beside it when the window is wide.
- **Screens**: one list of every screen and what each shows (below): the ones this Mac drives, then the venue's
  other screens (`VenueScreens.swift`: Apple TVs, Google TVs, other Macs' displays), each connected now or with when
  it last was. Every screen with a display record has **Edit…** (name, off, the song playing, its ranking, forget),
  this Mac's own displays included once they've shown; a screen code, Events & series or an admin's sign-in can save.
  Every such screen also has a **group menu** (`ScreenGroupMenu`): on its own, or in one of the venue's screen groups
  ("Bar TVs"), which hold one setup that every screen in them shows (the API's `VenueDisplayGroup`; a grouped display
  answers with its group's ranking, so the boards follow with no code of their own). Groups have rows of their own
  after the screens, with **Edit…** (`VenueScreenGroupEditor`) and **New Screen Group…**. The menus stay away until
  the server answers for groups.
- **Events** (`EventsTab.swift`): tonight's and upcoming events with who's on, RSVPs, the playlist (Play Now) and the
  running order. A code with Events & series advances the running order (Next Act, Back) while the event runs.
- **Chat** (`ChatTab.swift`): the venue's public room, live. A code with Chat & moderation posts as the venue, posts and
  pins announcements and removes messages; a screen code only reads.
- **Back of House** (`BackOfHouseTab.swift`): the venue's, its city's and each upcoming event's private room, with the
  conversation, file sharing from the Mac, the checklist, the lineup's tracks and who's in the room. Needs a code with
  Events & series or Chat & moderation.
- **Music**: Spotify now playing, tonight's playlists, the music folder and the sing-along lyrics tools.

Opening at login, what the code allows and Sign Out are in Settings (⌘,).

Open `apps/velvet/VelvetDisplay.xcodeproj` and run the **Velvet Display Next** scheme (Debug and Release talk to the next
preview, `https://api.next.audiencekit.com`) or **Velvet Display Production** (production). Signing team `DWVXMLB45Y`,
macOS 14 or later. It shares Velvet's bundle ID, `com.audiencekit.Velvet` (one bundle ID per app), as Velvet's macOS
platform on App Store Connect app 6820764256. Its device sign-in is one keychain item per server: service `com.audiencekit.Velvet`
(the bundle ID) for Production, `com.audiencekit.Velvet.next` for Next, each shared by App Store and Developer ID builds.
It opens for the app's designated requirement (team and bundle ID), which both signings meet, so moving between the
download and the App Store app keeps the sign-in. One item for both servers lost the code: a server refusing the other's
session ended it. Why a session ended is logged (Console, subsystem `com.audiencekit.Velvet`, category `session`).

**Sign in with Apple** (App Store and TestFlight builds carry `com.apple.developer.applesignin` and use the system
sheet; Apple doesn't grant that entitlement to Developer ID apps, so the download's Continue with Apple opens Apple's
web sign-in in a browser sheet instead, `AppleWebSignIn.swift` and StaffKit's `AppleWebOAuth`, the flow the Android
staff apps use): a venue manager signs in, picks one of the venues they
work from the list, and the Mac makes itself a device code for that venue (`issueVenueDevice`, permissions events,
moderation and music, falling back to events) and redeems it. The person's own sign-in then ends, so the Mac only ever
holds a device session. Builds before this read
`com.audiencekit.VelvetDisplay.{next,production}.audiencekit`; the first launch moves that sign-in over and deletes it.

## Setting it up at a venue

1. In Velvet on an iPhone or iPad, open the venue's Settings › Devices & codes and make a code with **Events & series**
   (the lineup). Add **Chat & moderation** to put the room's chat beside it.
2. On the Mac, enter the code. The Mac signs in as that venue device only, never as a person; revoking the device in
   Velvet takes the screen back to sign-in.
3. Pick the screens and press **Show** (⌘↩). ⌘. stops them all; on the Mac's own display, Escape does too.
   Showing never moves the Mac's sound: if macOS switches the output to a TV's or display's speakers (HDMI,
   DisplayPort or AirPlay) in the 30 seconds after Show or a display change, Velvet puts it back on the speakers that
   were playing (`AudioOutputGuard.swift`). Picking a TV's speakers yourself later is left alone.
   All of them are in one **Screens** list, each row with what kind it is, its name (pencil), Edit…, a switch (only on the screens this Mac drives) and what it
   shows:
   - **Displays**: any number of displays plugged into the Mac (the first one that isn't the Mac's main display is
     picked for you).
   - **Chromecasts**: Chromecasts and Google TVs found on the network (Bonjour `_googlecast._tcp`). The Mac speaks the
     Cast protocol itself (`MacCast.swift`): it launches Velvet's Cast receiver (`B2AF7F85`) and sends the board as
     text on `urn:x-cast:com.audiencekit.velvet`, the same messages the iPhone sends, and reconnects after a drop.
   - **AirPlay TVs**: Apple TVs and TVs with AirPlay found on the network (Bonjour `_airplay._tcp`; Macs, HomePods and
     AirPort speakers are left out) are listed by name, and ticking one adds it, no System Settings needed. Apps can't
     make an AirPlay TV a display, so the Mac puts the board in a window off every screen and records it with
     ScreenCaptureKit at up to 30 frames a second, blurs and motion included (`WindowCapture.swift`; macOS asks once to
     allow Screen Recording, and until then it draws the view twice a second, flat), encodes it as live HLS in one-second
     segments
     (`MarqueeEncoder`/`MarqueeServer` in `VenueMarqueeUI`, shared with the iPhone's AirPlay stream) and plays it in one
     muted player per TV. macOS gives apps no way to pick an AirPlay route themselves, so after Show click the row's
     AirPlay button and pick the TV (again after a restart). **Add Another AirPlay TV** adds one that isn't listed.
   - **AirPlay TVs as displays (live picture)**: in Control Center › Screen Mirroring, pick the TV and choose **Use As
     Separate Display**. macOS then treats it as a display, so it's listed as a display (and no longer as an AirPlay
     TV), shows the board live, and stays connected while the Mac runs. An app can't start this itself (no public
     API); **Use an AirPlay TV as a Display…** opens Displays settings.
4. Turn on **Open Velvet Display when this Mac starts**, so the displays and Chromecasts come back on their own after a
   restart.
5. Optionally turn on **Show what Spotify is playing**: with the Spotify app playing on the same Mac, the board shows
   the song, artist and cover along the bottom of the lineup. No Spotify sign-in: Spotify announces each track change
   to the Mac (`com.spotify.client.PlaybackStateChanged`), and the cover comes from asking Spotify over Apple Events,
   which macOS allows once (the `temporary-exception.apple-events` entitlement for `com.spotify.client`).

While it's showing, the display doesn't sleep and the pointer stays hidden over it. Unplugging the TV takes the board
down; plugging it back in (or waking the Mac) puts it back up. The venue is re-read every five minutes; the lineup every
minute and the chat live, as on the iPad.

## A different screen on each display

Each display picked in setup has its own **Shows** menu: Lineup and chat (the whole board, the default), Lineup only,
Chat wall, Event posters, Photo wall, or Sing-along lyrics. It's kept by the display's name. AirPlay TVs (video) have
the same menu; an AirPlay TV used as a separate display is a display like any other. Chromecasts have every choice but
Bingo and trivia: for a Photo wall TV the Mac sends the wall's photos (`photos`, read every 10 minutes), and it sends the receiver the song playing (`nowPlaying`), the next nights' events for a night with no lineup
(`comingUp`), and for Sing-along lyrics the song's timed lines (`lyrics`) plus Spotify's clock whenever it moves
(`{"type":"clock"}`), so the TV keeps the lines in time itself.

**Sing-along lyrics** show the line being sung, big, with the one before and the next two, and nothing else. They
follow Spotify on this Mac ("Show what Spotify is playing" must be on): Spotify's position comes with each play, pause
and track change, and is read again every 3 seconds. The words come only from where the venue may show them:
- its own LRC files in `~/Library/Application Support/Velvet Display/Lyrics` ("Artist - Title.lrc", the title alone,
  or the Spotify track ID), as a karaoke or sing-along licence supplies them;
- AudienceKit's, which fetches them from Musixmatch with its own key and keeps them, so the Mac has no lyrics key:
  a timing another venue shared (`Venue.music.lyricTimings`) with its words (`syncedLines`), else the song's words
  (`Venue.music.lyrics`), synced or put to the shared timing.

**Music folder.** Choose the venue's music folder in setup and Velvet Display goes through every audio file in it
(`MusicFolder`), songs on no playlist too: it finds each in MusicBrainz as the Song window does, fetches its words
through AudienceKit into `Velvet Display/Lyrics Cache` under the name the aligner looks for, and checks whether it's
timed here or by another venue. Setup shows the counts and the `velvet-align --folder` command that times the rest. It
scans when it opens and every six hours, only new or changed files after the first time (`Music Folder/songs.json`).
The folder is kept as a security-scoped bookmark (`files.bookmarks.app-scope`).

**AudienceKit playlists.** "Tonight's music" lists the audience's playlists and albums in AudienceKit
(`Audience.media.playlists`, those on Spotify): pick one and Play, shuffled as the playlist says.

Every minute, each LRC named for its Spotify track ID ("<id>.lrc") that changed is shared with every venue
(`reportLyricTiming`, API #765) when the device code has the music permission: only line times and digests, never the
words. `[ti:]`, `[ar:]`, `[length:]` and `[matched:N]` (lines timed from the audio) tags go with it.

## Opening a song: MusicBrainz and fingerprints

**File › Open Song…** (⌘O), or **Open a Song…** in the sing-along section, opens the Song window: choose (or drop) an
audio file of a song the venue owns, such as a FLAC bought from Qobuz, and it shows who the song is and what the
screens would show for it, line by line with each line's time and each syllable's, lighting up as it plays (Space).
Click a line to jump there.

Who it is (`SongIdentifier` in StaffKitServices) comes from, most certain first:
1. the file's MusicBrainz recording ID tag (MusicBrainz Picard writes `MUSICBRAINZ_TRACKID`);
2. its ISRC (`ISRC`, which stores put in FLACs), looked up in MusicBrainz;
3. its Chromaprint fingerprint, matched by AcoustID, only when an AcoustID key is entered in the window's lookup
   settings (AcoustID is free for non-commercial use only, so a venue enters a key it may use);
4. a MusicBrainz search on its title, artist and length (a score of 90 or more, within ten seconds).

The fingerprint is made on this Mac (`Chromaprint.swift`: Chromaprint's default algorithm in Swift, the same bits as
`fpcalc`, since the sandboxed app can't run `fpcalc`). MusicBrainz is asked at most once a second, as it asks of every
application, with `VelvetDisplay/<version> ( https://audiencekit.com )` as the User-Agent and no one's email. A venue
running its own MusicBrainz mirror (musicbrainz-docker) enters its address in the lookup settings, which has no limit.

What it finds (the recording's MBID, ISRC, fingerprint, release and the works it performs, with their ISWCs; never
lyrics) is kept in `~/Library/Application Support/Velvet Display/Identity`, one JSON file per recording. A timing file
the aligner made for a song with no Spotify track is then shared by its MusicBrainz recording (`reportLyricTiming`
with `musicbrainzRecordingId`), and any venue whose copy MusicBrainz knows as the same recording finds it
(`Venue.music.lyricTimings(musicbrainzRecordingIds:)`, or by ISRC). **Share Timing by MusicBrainz ID** in the window
shares the open song's timing right away.

## Checking a build

```sh
xcodebuild -project apps/velvet/VelvetDisplay.xcodeproj -scheme "Velvet Display Next" -configuration Debug \
  -destination 'platform=macOS' CODE_SIGNING_ALLOWED=NO build
```

## App Store screenshots

`VelvetDisplayUITests` signs in to the demo venue (The Review Room) with its device code, which is the demo
audience's App Review code, and keeps three 2880×1800 Mac App Store screenshots: the device code screen, the setup
window signed in (each on Velvet's dark backdrop with a caption) and the marquee full screen. Run it on a Mac against
an API that has the demo audience (`rake ui_tests:setup` locally, or `rake app_review:venue`):

```sh
AK_REVIEW_CODE=XXXX-XXXX-XXXX-XXXX AK_API_URL=http://127.0.0.1:3000 \
  scripts/velvet-display-screenshots.sh ~/Desktop/velvet-display-shots
```

The test launches the app with `AK_UI_TEST_SIGNED_OUT=1`, so it signs in through a keychain item of its own and
never signs the Mac's real screen out, and it shows the board on the main display for a few seconds without changing
the display the Mac normally uses.

## The download (Developer ID, with Sparkle updates)

audiencekit.com/apps/velvet/ offers a Developer ID build, `https://audiencekit.com/downloads/VelvetDisplay.zip`, which
updates itself with [Sparkle](https://sparkle-project.org). Its feed is the API's appcast,
`https://api.audiencekit.com/v1/app_release/appcast?app=com.audiencekit.Velvet`, made live from Velvet's
`developer_id` release and signed by the API with the Sparkle EdDSA key in its credentials (`sparkle.ed25519_private_key`).
The same key sits in the login keychain of the Mac that builds the download (account `velvet-display`), which reads
only its public half for `SUPublicEDKey`:

```sh
scripts/velvet-display-direct.sh ~/Desktop/velvet-display          # a local build
scripts/velvet-display-direct.sh --ship ~/Desktop/velvet-display   # the download
```

Local Mac builds are always Developer ID builds. The script archives, exports for Developer ID, adds
Sparkle.framework and the feed keys, signs with `VelvetDisplay-Direct.entitlements` (the app's entitlements plus the
mach-lookup exceptions sandboxed Sparkle needs) and zips. Only `--ship` notarizes and staples, checks Gatekeeper,
writes `release.json` and reports the release (build, version, download URL, sha256) to the API with
`AK_RELEASE_TOKEN` or the keychain token (service `com.audiencekit.Velvet.release`). Notarize only to ship the
download. Put the zip in audience-kit.github.io `public/downloads/` with a PR to main. The appcast offers the build only once the zip on the
site matches the reported sha256. The build number is the commit count, so each build is newer than the last.

The App Store build has no Sparkle in it: nothing in the Xcode project links it. `Updates.swift` loads Sparkle at run
time only when the bundle has the framework and `SUFeedURL`, and only then shows **Check for Updates…** in the app menu.

## Xcode Cloud

The Velvet product's **Velvet Display Next** workflow builds `apps/velvet/VelvetDisplay.xcodeproj` from `next` with the
"Velvet Display Next" scheme and archives it for macOS TestFlight (internal testers). `apps/velvet/ci_scripts/ci_post_clone.sh`
checks out the AudienceKit SDK submodule, as `apps/ci_scripts` does for Staff.xcodeproj.

## Tonight's music: event playlists and sing-along nights

An event or series with a playlist (`Event.playlist`, a Spotify link set in Velvet) plays in Spotify on this Mac while the
event runs (`NightMusic`), shuffled unless the playlist says otherwise. When the event is a sing-along night (karaoke
with the sing_along provider, `karaoke.singAlong`, or the sing_along facet's tag), every chosen screen turns to the
sing-along lyrics, and goes back to what it showed when the event ends. The setup window's "Tonight's music" section
lists tonight's nights with Play Now, takes a pasted Spotify link, and ends a night by hand.

"Time a song's lyrics" (`LyricTiming`, in the sing-along section) makes an LRC file from pasted lyrics and an audio file
of the song the venue owns: macOS speech recognition hears the song on this Mac, `LyricAligner` (StaffKitServices)
matches the heard words to the lines, and the file goes into the Lyrics folder. It's a first draft to check.

### Syllable captions

The sing-along screen is closed captioning, not karaoke. The lines scroll up the way Apple Music's lyrics do, and a highlight sweeps across the line being sung one syllable at a time. Behind the words is the song's cover art, dimmed, blurred and drifting slowly (Ken Burns). There is no bouncing ball. A mashup (several works sung at once) gets attribution only; a medley names each song as it starts.

Where the syllable timing comes from (`SyllableCaptions`), in order:

1. **Venue TTML.** The venue's own TTML file in the Lyrics folder ("Artist - Title.ttml" or "<Spotify ID>.ttml").
2. **Aligned timing.** A Velvet JSON timing file (`velvet-syllables/1`, StaffKit's `SyllableTiming`) in `~/Library/Application Support/Velvet Display/Timing`. `tools/velvet-align` makes these on this Mac from an audio file the venue owns (Demucs, wav2vec2, CMUdict). The file keeps times and line digests, never words, and is joined to the words at show time. Setup's "Syllable captions" shows the command, filled in for the playing song. New files are picked up within 15 seconds.
3. **Estimated.** Otherwise, syllables are spread over the line timing (`SyllableLyrics.estimated`).

When the words are the venue's own (its LRC files), a TTML copy of aligned timing is kept beside the JSON for other players. "Export Playing Song as TTML" writes the song on screen to Timing/Exports when the venue asks for it. Timing stays on this Mac for now; sharing it between venues comes later. The identity model behind it (works, recordings, releases, medley and mashup links, film segments) is in StaffKit's `MediaIdentity.swift`.

Each display's "Shows" is All by default: the lineup and chat, with event posters, photographers' photos, slogans and
the safety screen taking turns between looks at it. Picking one thing (lineup only, chat wall, event posters, photo
wall, sing-along lyrics) is the override for that screen.

The **Photo wall** is the venue's trusted photographers' recent photos: the photographers the audience connected in
Olympus (the Photography module), never members' crowd photos and never a photo a manager hid or someone reported. One
photo large with up to four beside it, each credited, turning over every 12 seconds. Only photos taken in the last 90
days count, so it has nothing to show at a venue no photographer has been to lately (`MarqueePhotos.hasContent`), and
a screen that ranks its types moves on to the next.

The poster loop (event posters on their own screen, and the slides between looks at the board) also has a **follow
us** slide once after every round of posters: the venue's social media profiles from its listing (Instagram, TikTok,
Facebook, X, Threads, Bluesky, YouTube, Linktree, Discord; at most four, never tip links), each with a QR code. With no
posters it takes their place. Chromecasts get the same profiles (`social`).
