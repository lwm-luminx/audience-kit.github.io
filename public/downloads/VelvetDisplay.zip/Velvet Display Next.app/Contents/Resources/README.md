# Velvet Display (macOS)

A Mac plugged into the venue's TV shows Velvet's marquee full screen on the display you pick: tonight's lineup with
whoever is on now, the Hot Mess join code, the Hot Mess slogan slides the venue has on, and the room's live chat. It is
the same board Velvet on an iPhone or iPad puts on a TV (`VenueMarqueeBoard` in StaffKit's `VenueMarqueeUI` library,
`swift/Sources/VenueMarqueeUI`), so a change to the marquee shows up on both. The library builds for iOS, macOS and
tvOS, ready for an Apple TV app.

Open `apps/velvet/VelvetDisplay.xcodeproj` and run the **Velvet Display Next** scheme (Debug and Release talk to the next
preview, `https://api.next.audiencekit.com`) or **Velvet Display Production** (production). Signing team `DWVXMLB45Y`,
macOS 14 or later. It shares Velvet's bundle ID, `com.audiencekit.Velvet` (one bundle ID per app), as Velvet's macOS
platform on App Store Connect app 6820764256. Its device sign-in has its own keychain service
(`com.audiencekit.VelvetDisplay.*`), separate from the iOS app's.

## Setting it up at a venue

1. In Velvet on an iPhone or iPad, open the venue's Settings › Devices & codes and make a code with **Events & series**
   (the lineup). Add **Chat & moderation** to put the room's chat beside it.
2. On the Mac, enter the code. The Mac signs in as that venue device only, never as a person; revoking the device in
   Velvet takes the screen back to sign-in.
3. Pick the display (the first one that isn't the Mac's main display is chosen for you) and press **Show on Display**
   (⌘↩). ⌘. stops it; on the Mac's own display, Escape does too.
4. Turn on **Open Velvet Display when this Mac starts**, so the TV comes back on its own after a restart.
5. Optionally turn on **Show what Spotify is playing**: with the Spotify app playing on the same Mac, the board shows
   the song, artist and cover along the bottom of the lineup. No Spotify sign-in: Spotify announces each track change
   to the Mac (`com.spotify.client.PlaybackStateChanged`), and the cover comes from asking Spotify over Apple Events,
   which macOS allows once (the `temporary-exception.apple-events` entitlement for `com.spotify.client`).

While it's showing, the display doesn't sleep and the pointer stays hidden over it. Unplugging the TV takes the board
down; plugging it back in (or waking the Mac) puts it back up. The venue is re-read every five minutes; the lineup every
minute and the chat live, as on the iPad.

## Checking a build

```sh
xcodebuild -project apps/velvet/VelvetDisplay.xcodeproj -scheme "Velvet Display Next" -configuration Debug \
  -destination 'platform=macOS' CODE_SIGNING_ALLOWED=NO build
```

## App Store screenshots

`VelvetDisplayUITests` signs in to the demo venue (The Review Room) with its device code, which is the demo
audience's App Review code, and keeps three 2880×1800 Mac App Store screenshots: the device code screen, the setup
window signed in (each on Velvet's dark backdrop with a caption) and the marquee full screen. Run it on a Mac against
an API that has the demo audience (`rake ui_tests:setup` locally, or `rake app_review:venue`):

```sh
AK_REVIEW_CODE=XXXX-XXXX-XXXX-XXXX AK_API_URL=http://127.0.0.1:3000 \
  scripts/velvet-display-screenshots.sh ~/Desktop/velvet-display-shots
```

The test launches the app with `AK_UI_TEST_SIGNED_OUT=1`, so it signs in through a keychain item of its own and
never signs the Mac's real screen out, and it shows the board on the main display for a few seconds without changing
the display the Mac normally uses.

## Xcode Cloud

The Velvet product's **Velvet Display Next** workflow builds `apps/velvet/VelvetDisplay.xcodeproj` from `next` with the
"Velvet Display Next" scheme and archives it for macOS TestFlight (internal testers). `apps/velvet/ci_scripts/ci_post_clone.sh`
checks out the AudienceKit SDK submodule, as `apps/ci_scripts` does for Staff.xcodeproj.
